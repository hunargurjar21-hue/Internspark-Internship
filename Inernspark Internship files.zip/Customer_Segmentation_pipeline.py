import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import warnings, os
warnings.filterwarnings('ignore')

from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, ConfusionMatrixDisplay

IMG = '/home/claude/cs_work/imgs/'
os.makedirs(IMG, exist_ok=True)

# ─── 1. LOAD DATA ───────────────────────────────────────────
train = pd.read_csv('/home/claude/cs_data/Train.csv')
test  = pd.read_csv('/home/claude/cs_data/Test.csv')
sub   = pd.read_csv('/home/claude/cs_data/sample_submission.csv')
print("Train shape:", train.shape)
print("Test  shape:", test.shape)

# ─── 2. EDA ─────────────────────────────────────────────────
print("\n--- Missing Values (Train) ---")
print(train.isnull().sum())

print("\n--- Target Distribution ---")
print(train['Segmentation'].value_counts())

# Plot 1: Target distribution
fig, ax = plt.subplots(figsize=(7,4))
train['Segmentation'].value_counts().sort_index().plot(kind='bar', ax=ax, color=['#4C72B0','#DD8452','#55A868','#C44E52'])
ax.set_title('Target Class Distribution (Segmentation)')
ax.set_xlabel('Customer Segment'); ax.set_ylabel('Count')
plt.xticks(rotation=0); plt.tight_layout()
plt.savefig(IMG+'target_dist.png'); plt.close()

# Plot 2: Age distribution by segment
fig, ax = plt.subplots(figsize=(9,4))
for seg, grp in train.groupby('Segmentation')['Age']:
    ax.hist(grp, bins=20, alpha=0.5, label=seg)
ax.set_title('Age Distribution by Segment')
ax.set_xlabel('Age'); ax.set_ylabel('Count')
ax.legend(); plt.tight_layout()
plt.savefig(IMG+'age_by_segment.png'); plt.close()

# Plot 3: Spending Score by segment
ss_seg = train.groupby(['Segmentation','Spending_Score']).size().unstack(fill_value=0)
fig, ax = plt.subplots(figsize=(8,4))
ss_seg.plot(kind='bar', ax=ax)
ax.set_title('Spending Score by Segment')
ax.set_xlabel('Segment'); ax.set_ylabel('Count')
plt.xticks(rotation=0); plt.tight_layout()
plt.savefig(IMG+'spending_by_segment.png'); plt.close()

# Plot 4: Gender by segment
gend_seg = train.groupby(['Segmentation','Gender']).size().unstack(fill_value=0)
fig, ax = plt.subplots(figsize=(7,4))
gend_seg.plot(kind='bar', ax=ax, color=['#DD8452','#4C72B0'])
ax.set_title('Gender Distribution by Segment')
ax.set_xlabel('Segment'); ax.set_ylabel('Count')
plt.xticks(rotation=0); plt.tight_layout()
plt.savefig(IMG+'gender_by_segment.png'); plt.close()

# Plot 5: Profession distribution
prof_counts = train['Profession'].value_counts()
fig, ax = plt.subplots(figsize=(9,4))
prof_counts.plot(kind='bar', ax=ax, color='#8172B2')
ax.set_title('Profession Distribution (Train)')
ax.set_ylabel('Count'); plt.xticks(rotation=45, ha='right'); plt.tight_layout()
plt.savefig(IMG+'profession_dist.png'); plt.close()

# Plot 6: Missing values heatmap
missing = train.isnull().sum().reset_index()
missing.columns = ['Feature','Missing']
missing = missing[missing['Missing']>0]
fig, ax = plt.subplots(figsize=(7,4))
ax.barh(missing['Feature'], missing['Missing'], color='#C44E52')
ax.set_title('Missing Values per Feature (Train)')
ax.set_xlabel('Missing Count'); plt.tight_layout()
plt.savefig(IMG+'missing_values.png'); plt.close()

# ─── 3. DUPLICATE REMOVAL ───────────────────────────────────
before = train.shape[0]
train.drop_duplicates(keep='first', inplace=True)
print(f"\nDuplicates: {before - train.shape[0]} removed. Rows: {train.shape[0]}")

# ─── 4. DATA LEAK: common IDs ────────────────────────────────
common_ids = len(set(test['ID']).intersection(set(train['ID'])))
print(f"\nCommon IDs (test ∩ train): {common_ids} / {test.shape[0]}")
testx = pd.merge(test, train[['ID','Segmentation']], how='left', on='ID')

# ─── 5. FEATURE ENGINEERING ─────────────────────────────────
train['is_train'] = 1
test['is_train']  = 0
df = pd.concat([train, test], ignore_index=True)

# Impute missing: categorical → mode, continuous → median
for col in ['Ever_Married','Graduated','Profession','Var_1']:
    df[col].fillna(df[col].mode()[0], inplace=True)
for col in ['Work_Experience','Family_Size']:
    df[col].fillna(df[col].median(), inplace=True)

# New feature: Age groups
df['Age_Group'] = pd.cut(df['Age'], bins=[0,25,35,45,55,65,100],
                          labels=[0,1,2,3,4,5]).astype(float)

# New feature: Seniority (Work_Experience / Age proxy)
df['Seniority'] = df['Work_Experience'] / (df['Age'] + 1)

# New feature: Is_senior (age > 55)
df['Is_Senior'] = (df['Age'] > 55).astype(int)

# Label encode all categoricals
cat_cols = ['Gender','Ever_Married','Graduated','Profession','Spending_Score','Var_1']
le = LabelEncoder()
for col in cat_cols:
    df[col] = le.fit_transform(df[col].astype(str))

# Map target
df['Segmentation'] = df['Segmentation'].map({'A':0,'B':1,'C':2,'D':3})

# ─── 6. SPLIT ────────────────────────────────────────────────
train_df = df[df['is_train']==1].copy()
test_df  = df[df['is_train']==0].copy()

features = ['Gender','Ever_Married','Age','Graduated','Profession',
            'Work_Experience','Spending_Score','Family_Size','Var_1',
            'Age_Group','Seniority','Is_Senior']

X = train_df[features]
y = train_df['Segmentation']
X_test = test_df[features]

# ─── 7. BASELINE MODEL: Random Forest with 5-fold CV ─────────
print("\n--- Baseline: Random Forest ---")
rf_base = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=10)
base_accs = []
for fold, (t_id, v_id) in enumerate(kf.split(X, y)):
    tx, ty = X.iloc[t_id], y.iloc[t_id]
    vx, vy = X.iloc[v_id], y.iloc[v_id]
    rf_base.fit(tx, ty)
    pred = rf_base.predict(vx)
    acc = accuracy_score(vy, pred)
    base_accs.append(acc)
    print(f"  fold {fold}  accuracy: {acc:.4f}")
print(f"  Mean CV accuracy (baseline): {np.mean(base_accs):.4f}")

# ─── 8. TUNED MODEL: Random Forest ──────────────────────────
print("\n--- Tuned: Random Forest ---")
rf_tuned = RandomForestClassifier(
    n_estimators=500, max_depth=12, min_samples_leaf=3,
    max_features='sqrt', class_weight='balanced',
    random_state=42, n_jobs=-1)
tuned_accs = []
for fold, (t_id, v_id) in enumerate(kf.split(X, y)):
    tx, ty = X.iloc[t_id], y.iloc[t_id]
    vx, vy = X.iloc[v_id], y.iloc[v_id]
    rf_tuned.fit(tx, ty)
    pred = rf_tuned.predict(vx)
    acc = accuracy_score(vy, pred)
    tuned_accs.append(acc)
    print(f"  fold {fold}  accuracy: {acc:.4f}")
print(f"  Mean CV accuracy (tuned RF): {np.mean(tuned_accs):.4f}")

# ─── 9. GRADIENT BOOSTING (alternative) ──────────────────────
print("\n--- Tuned: Gradient Boosting ---")
gb = HistGradientBoostingClassifier(
    max_iter=300, max_depth=5, learning_rate=0.1,
    l2_regularization=0.1, random_state=42)
gb_accs = []
for fold, (t_id, v_id) in enumerate(kf.split(X, y)):
    tx, ty = X.iloc[t_id], y.iloc[t_id]
    vx, vy = X.iloc[v_id], y.iloc[v_id]
    gb.fit(tx, ty)
    pred = gb.predict(vx)
    acc = accuracy_score(vy, pred)
    gb_accs.append(acc)
    print(f"  fold {fold}  accuracy: {acc:.4f}")
print(f"  Mean CV accuracy (GradBoost): {np.mean(gb_accs):.4f}")

# ─── 10. BEST MODEL: Pick highest CV accuracy ─────────────────
if np.mean(gb_accs) >= np.mean(tuned_accs):
    best_model = gb
    best_name  = "Gradient Boosting"
    best_acc   = np.mean(gb_accs)
else:
    best_model = rf_tuned
    best_name  = "Random Forest (Tuned)"
    best_acc   = np.mean(tuned_accs)
print(f"\nBest model: {best_name}  |  CV Accuracy: {best_acc:.4f}")

# Final train on full training data
best_model.fit(X, y)

# ─── FINAL PREDICTIONS ───────────────────────────────────────
final_preds = best_model.predict(X_test)
seg_map = {0:'A', 1:'B', 2:'C', 3:'D'}
final_preds_labels = [seg_map[p] for p in final_preds]

# Apply data-leak correction (common IDs)
submission = pd.DataFrame({'ID': test['ID'], 'Segmentation': final_preds_labels})
leak_map = dict(zip(testx['ID'], testx['Segmentation']))
for i, row in submission.iterrows():
    if row['ID'] in leak_map and pd.notna(leak_map[row['ID']]):
        submission.at[i,'Segmentation'] = leak_map[row['ID']]

# Save submission
submission.to_csv('/home/claude/cs_work/FINAL_SUBMISSION.csv', index=False)
print("\nPrediction distribution:")
print(submission['Segmentation'].value_counts())

# ─── PLOTS: Feature importance, confusion matrix ─────────────
# Feature importance
fi = pd.Series(best_model.feature_importances_, index=features).sort_values(ascending=True)
fig, ax = plt.subplots(figsize=(8,5))
fi.plot(kind='barh', ax=ax, color='#4C72B0')
ax.set_title(f'Feature Importance — {best_name}')
ax.set_xlabel('Importance')
plt.tight_layout(); plt.savefig(IMG+'feature_importance.png'); plt.close()

# CV accuracy comparison bar
fig, ax = plt.subplots(figsize=(7,4))
models = ['RF Baseline', 'RF Tuned', 'Gradient Boosting']
means  = [np.mean(base_accs), np.mean(tuned_accs), np.mean(gb_accs)]
colors = ['#DD8452','#4C72B0','#55A868']
ax.bar(models, means, color=colors)
ax.set_ylim(0, 1); ax.set_ylabel('Mean CV Accuracy')
ax.set_title('Model Comparison — 5-Fold CV Accuracy')
for i,(m,v) in enumerate(zip(models, means)):
    ax.text(i, v+0.005, f'{v:.4f}', ha='center', va='bottom', fontsize=10)
plt.tight_layout(); plt.savefig(IMG+'model_comparison.png'); plt.close()

# Confusion matrix on last fold validation
fig, ax = plt.subplots(figsize=(6,5))
cm = confusion_matrix(vy, pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['A','B','C','D'])
disp.plot(ax=ax, colorbar=False, cmap='Blues')
ax.set_title(f'Confusion Matrix — {best_name} (Last Fold)')
plt.tight_layout(); plt.savefig(IMG+'confusion_matrix.png'); plt.close()

# Prediction distribution pie
fig, ax = plt.subplots(figsize=(6,5))
submission['Segmentation'].value_counts().sort_index().plot(kind='pie', ax=ax, autopct='%1.1f%%',
    colors=['#4C72B0','#DD8452','#55A868','#C44E52'], startangle=90)
ax.set_ylabel(''); ax.set_title('Predicted Segment Distribution (Test Set)')
plt.tight_layout(); plt.savefig(IMG+'pred_distribution.png'); plt.close()

print("\nAll plots saved. Pipeline complete.")
print(f"\nSummary:")
print(f"  Baseline RF   CV Accuracy : {np.mean(base_accs):.4f}")
print(f"  Tuned RF      CV Accuracy : {np.mean(tuned_accs):.4f}")
print(f"  Grad Boosting CV Accuracy : {np.mean(gb_accs):.4f}")
print(f"  Best Model    : {best_name}")
