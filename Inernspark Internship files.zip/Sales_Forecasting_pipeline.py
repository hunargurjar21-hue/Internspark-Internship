import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import GradientBoostingRegressor, HistGradientBoostingRegressor
from sklearn.metrics import mean_squared_error
import warnings
warnings.filterwarnings('ignore')

IMG = '/home/claude/energy_work/imgs/'
plt.style.use('fivethirtyeight')
color_pal = sns.color_palette()

# ── 1. LOAD DATA ─────────────────────────────────────────────
df = pd.read_csv('/home/claude/energy_data/PJME_hourly.csv')
df['Datetime'] = pd.to_datetime(df['Datetime'])
df = df.set_index('Datetime').sort_index()
print("Shape:", df.shape)
print("Date range:", df.index.min(), "to", df.index.max())
print("Missing:", df.isnull().sum().values[0])

# ── 2. FULL SERIES PLOT ───────────────────────────────────────
fig, ax = plt.subplots(figsize=(15, 5))
df.plot(style='.', color=color_pal[0], ax=ax, ms=1,
        title='PJME Hourly Energy Use in MW (2002–2018)')
ax.set_xlabel('Datetime'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'01_full_series.png', dpi=100); plt.close()

# ── 3. TRAIN / TEST SPLIT (cutoff = 2015-01-01) ──────────────
train = df.loc[df.index < '2015-01-01']
test  = df.loc[df.index >= '2015-01-01']
print(f"\nTrain: {train.shape[0]} rows | Test: {test.shape[0]} rows")

fig, ax = plt.subplots(figsize=(15, 5))
train['PJME_MW'].plot(ax=ax, label='Training Set', color=color_pal[0])
test['PJME_MW'].plot(ax=ax, label='Test Set', color=color_pal[1])
ax.axvline('2015-01-01', color='black', ls='--', lw=1.5)
ax.legend(); ax.set_title('Data Train/Test Split at 2015-01-01')
ax.set_xlabel('Datetime'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'02_train_test_split.png', dpi=100); plt.close()

# ── 4. WEEK OF DATA (sample) ──────────────────────────────────
fig, ax = plt.subplots(figsize=(15, 4))
df.loc[(df.index > '2010-01-01') & (df.index < '2010-01-08')]['PJME_MW'].plot(
    ax=ax, color=color_pal[0], title='Sample Week of Data (Jan 2010)')
ax.set_xlabel('Datetime'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'03_week_sample.png', dpi=100); plt.close()

# ── 5. FEATURE CREATION ──────────────────────────────────────
def create_features(df):
    df = df.copy()
    df['hour']       = df.index.hour
    df['dayofweek']  = df.index.dayofweek
    df['quarter']    = df.index.quarter
    df['month']      = df.index.month
    df['year']       = df.index.year
    df['dayofyear']  = df.index.dayofyear
    df['dayofmonth'] = df.index.day
    df['weekofyear'] = df.index.isocalendar().week.astype(int)
    # Lag features
    df['lag_24h']    = df['PJME_MW'].shift(24)
    df['lag_168h']   = df['PJME_MW'].shift(168)   # 1 week
    df['rolling_mean_24h'] = df['PJME_MW'].shift(1).rolling(24).mean()
    df['rolling_std_24h']  = df['PJME_MW'].shift(1).rolling(24).std()
    return df

df_feat = create_features(df)

# ── 6. EDA BOXPLOTS ───────────────────────────────────────────
fig, ax = plt.subplots(figsize=(12, 6))
sns.boxplot(data=df_feat, x='hour', y='PJME_MW', ax=ax, palette='tab20')
ax.set_title('Energy Use (MW) by Hour of Day'); ax.set_xlabel('Hour'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'04_mw_by_hour.png', dpi=100); plt.close()

fig, ax = plt.subplots(figsize=(10, 6))
sns.boxplot(data=df_feat, x='month', y='PJME_MW', ax=ax, palette='Blues')
ax.set_title('Energy Use (MW) by Month'); ax.set_xlabel('Month'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'05_mw_by_month.png', dpi=100); plt.close()

fig, ax = plt.subplots(figsize=(9, 5))
sns.boxplot(data=df_feat, x='dayofweek', y='PJME_MW', ax=ax,
            palette='Set2', order=[0,1,2,3,4,5,6])
ax.set_xticklabels(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])
ax.set_title('Energy Use (MW) by Day of Week'); ax.set_xlabel('Day'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'06_mw_by_dow.png', dpi=100); plt.close()

# ── 7. PREPARE TRAIN/TEST WITH FEATURES ──────────────────────
FEATURES = ['hour','dayofweek','quarter','month','year',
            'dayofyear','dayofmonth','weekofyear',
            'lag_24h','lag_168h','rolling_mean_24h','rolling_std_24h']
TARGET = 'PJME_MW'

train_f = df_feat.loc[df_feat.index < '2015-01-01'].copy()
test_f  = df_feat.loc[df_feat.index >= '2015-01-01'].copy()

# Drop NaNs from lag features (only affects start of series)
train_f = train_f.dropna(subset=FEATURES)
test_f  = test_f.dropna(subset=FEATURES)

X_train = train_f[FEATURES]; y_train = train_f[TARGET]
X_test  = test_f[FEATURES];  y_test  = test_f[TARGET]
print(f"\nTrain after feature prep: {X_train.shape}")
print(f"Test  after feature prep: {X_test.shape}")

# ── 8. BASELINE MODEL (no lag features) ──────────────────────
BASE_FEATURES = ['hour','dayofweek','quarter','month','year','dayofyear']
print("\n--- Baseline: HistGradientBoosting (time features only) ---")
reg_base = HistGradientBoostingRegressor(
    max_iter=500, max_depth=4, learning_rate=0.05, random_state=42)
reg_base.fit(X_train[BASE_FEATURES], y_train)
pred_base = reg_base.predict(X_test[BASE_FEATURES])
rmse_base = np.sqrt(mean_squared_error(y_test, pred_base))
print(f"Baseline RMSE: {rmse_base:.2f} MW")

# ── 9. TUNED MODEL (time + lag features) ─────────────────────
print("\n--- Tuned: HistGradientBoosting (time + lag features) ---")
reg_tuned = HistGradientBoostingRegressor(
    max_iter=1000, max_depth=6, learning_rate=0.03,
    min_samples_leaf=20, l2_regularization=0.1, random_state=42)
reg_tuned.fit(X_train, y_train)
pred_tuned = reg_tuned.predict(X_test)
rmse_tuned = np.sqrt(mean_squared_error(y_test, pred_tuned))
print(f"Tuned RMSE: {rmse_tuned:.2f} MW")

# ── 10. FEATURE IMPORTANCE ───────────────────────────────────
fi = pd.Series(reg_tuned._raw_predict(X_test).mean(),  # placeholder
               index=[0])
# Use permutation-style importance via score differences
from sklearn.inspection import permutation_importance
perm = permutation_importance(reg_tuned, X_test, y_test, n_repeats=5,
                               random_state=42, n_jobs=-1)
fi = pd.Series(perm.importances_mean, index=FEATURES).sort_values()

fig, ax = plt.subplots(figsize=(9, 6))
fi.plot(kind='barh', ax=ax, color=color_pal[0])
ax.set_title('Feature Importance (Permutation)')
ax.set_xlabel('Mean decrease in score')
plt.tight_layout(); plt.savefig(IMG+'07_feature_importance.png', dpi=100); plt.close()
print("\nTop features:\n", fi.sort_values(ascending=False).head(6))

# ── 11. FULL SERIES + PREDICTIONS PLOT ───────────────────────
test_plot = test_f.copy()
test_plot['prediction'] = pred_tuned

fig, ax = plt.subplots(figsize=(15, 5))
df['PJME_MW'].plot(ax=ax, color=color_pal[0], lw=0.5, label='Truth Data')
test_plot['prediction'].plot(ax=ax, style='.', ms=1,
                              color=color_pal[1], label='Predictions')
ax.axvline('2015-01-01', color='black', ls='--', lw=1)
ax.legend(); ax.set_title('Raw Data and Predictions (Test Set 2015–2018)')
ax.set_xlabel('Datetime'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'08_full_predictions.png', dpi=100); plt.close()

# ── 12. ZOOM: ONE WEEK OF PREDICTIONS ────────────────────────
week_mask = (test_plot.index > '2018-04-01') & (test_plot.index < '2018-04-08')
fig, ax = plt.subplots(figsize=(13, 5))
test_plot.loc[week_mask, 'PJME_MW'].plot(ax=ax, color=color_pal[0],
                                          lw=2, label='Truth Data')
test_plot.loc[week_mask, 'prediction'].plot(ax=ax, style='.',
                                             color=color_pal[1], ms=6, label='Prediction')
ax.legend(); ax.set_title('Week of Data: Truth vs Prediction (Apr 2018)')
ax.set_xlabel('Datetime'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'09_week_predictions.png', dpi=100); plt.close()

# ── 13. ERROR ANALYSIS ───────────────────────────────────────
test_plot['error'] = np.abs(test_plot['PJME_MW'] - test_plot['prediction'])
test_plot['date']  = test_plot.index.date
daily_err = test_plot.groupby('date')['error'].mean().sort_values(ascending=False)

print("\nTop 10 worst predicted days:")
print(daily_err.head(10).to_string())
print("\nTop 10 best predicted days:")
print(daily_err.tail(10).to_string())

# Plot worst day vs best day
worst_day = str(daily_err.index[0])
best_day  = str(daily_err.index[-1])

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
for ax, day, label, c in [(axes[0], worst_day, 'Worst', 1),
                           (axes[1], best_day,  'Best',  2)]:
    mask = (test_plot.index >= day) & (test_plot.index < day + ' 23:59')
    test_plot.loc[mask, 'PJME_MW'].plot(ax=ax, lw=2, color=color_pal[0], label='Truth')
    test_plot.loc[mask, 'prediction'].plot(ax=ax, style='.--', color=color_pal[c], label='Prediction')
    ax.legend(); ax.set_title(f'{label} Predicted Day: {day}')
    ax.set_xlabel('Hour'); ax.set_ylabel('MW')
plt.tight_layout(); plt.savefig(IMG+'10_best_worst_days.png', dpi=100); plt.close()

# Error distribution
fig, ax = plt.subplots(figsize=(9, 5))
test_plot['error'].hist(bins=80, ax=ax, color=color_pal[0], edgecolor='white')
ax.set_title('Prediction Error Distribution (Absolute Error in MW)')
ax.set_xlabel('Absolute Error (MW)'); ax.set_ylabel('Count')
plt.tight_layout(); plt.savefig(IMG+'11_error_dist.png', dpi=100); plt.close()

# Model RMSE comparison bar
fig, ax = plt.subplots(figsize=(7, 4))
ax.bar(['Baseline\n(time features)', 'Tuned\n(+lag features)'],
       [rmse_base, rmse_tuned], color=[color_pal[1], color_pal[0]])
for i, v in enumerate([rmse_base, rmse_tuned]):
    ax.text(i, v + 30, f'{v:.1f}', ha='center', fontsize=12, fontweight='bold')
ax.set_ylabel('RMSE (MW)'); ax.set_title('Model RMSE Comparison')
plt.tight_layout(); plt.savefig(IMG+'12_model_comparison.png', dpi=100); plt.close()

# Save predictions
test_plot[['PJME_MW','prediction','error']].to_csv(
    '/home/claude/energy_work/PJME_predictions.csv')

print(f"\n=== FINAL SUMMARY ===")
print(f"Baseline RMSE : {rmse_base:.2f} MW")
print(f"Tuned RMSE    : {rmse_tuned:.2f} MW")
print(f"Improvement   : {rmse_base - rmse_tuned:.2f} MW ({(rmse_base-rmse_tuned)/rmse_base*100:.1f}%)")
print(f"Mean abs error: {test_plot['error'].mean():.2f} MW")
print(f"Median error  : {test_plot['error'].median():.2f} MW")
print(f"Worst day avg : {daily_err.iloc[0]:.2f} MW ({daily_err.index[0]})")
print(f"Best  day avg : {daily_err.iloc[-1]:.2f} MW ({daily_err.index[-1]})")
