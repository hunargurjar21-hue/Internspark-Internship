import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.rcParams['figure.dpi'] = 110

df = pd.read_csv('/home/claude/data/customer_shopping_data.csv')

# --- Cleaning ---
df['invoice_date'] = pd.to_datetime(df['invoice_date'], dayfirst=True)
df['total_sale'] = df['quantity'] * df['price']
df['year'] = df['invoice_date'].dt.year
df['month'] = df['invoice_date'].dt.month
df['quarter'] = df['invoice_date'].dt.to_period('Q')

print("Shape:", df.shape)
print("Duplicates:", df.duplicated().sum())
print("Nulls:\n", df.isnull().sum())
print("Date range:", df['invoice_date'].min(), "to", df['invoice_date'].max())

os_imgs = '/home/claude/work/imgs'
import os
os.makedirs(os_imgs, exist_ok=True)

# 1. Total sales & average price by category
cat_stats = df.groupby('category').agg(total_sales=('total_sale','sum'),
                                        avg_price=('price','mean'),
                                        orders=('invoice_no','count')).sort_values('total_sales', ascending=False)
print("\n--- Category stats ---\n", cat_stats)

fig, ax = plt.subplots(figsize=(9,5))
cat_stats['total_sales'].plot(kind='bar', color='#4C72B0', ax=ax)
ax.set_title('Total Sales by Category')
ax.set_ylabel('Total Sales (TRY)')
ax.set_xlabel('Category')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig(f'{os_imgs}/sales_by_category.png')
plt.close()

# 2. Gender x category total sales
gender_cat = df.groupby(['gender','category'])['total_sale'].sum().unstack()
print("\n--- Gender x Category total sales ---\n", gender_cat)

fig, ax = plt.subplots(figsize=(10,5))
gender_cat.T.plot(kind='bar', ax=ax, color=['#DD8452','#4C72B0'])
ax.set_title('Total Sales by Category and Gender')
ax.set_ylabel('Total Sales (TRY)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig(f'{os_imgs}/sales_by_category_gender.png')
plt.close()

# 3. Sales by shopping mall
mall_sales = df.groupby('shopping_mall')['total_sale'].sum().sort_values(ascending=False)
print("\n--- Sales by mall ---\n", mall_sales)

fig, ax = plt.subplots(figsize=(9,5))
mall_sales.plot(kind='bar', color='#55A868', ax=ax)
ax.set_title('Total Sales by Shopping Mall')
ax.set_ylabel('Total Sales (TRY)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig(f'{os_imgs}/sales_by_mall.png')
plt.close()

# 4. Monthly sales trend (across full date range)
monthly = df.groupby(df['invoice_date'].dt.to_period('M'))['total_sale'].sum()
print("\n--- Monthly total sales (head) ---\n", monthly.head())

fig, ax = plt.subplots(figsize=(12,5))
monthly.plot(marker='o', ax=ax, color='#4C72B0')
ax.set_title('Monthly Sales Trend (2021-2023)')
ax.set_ylabel('Total Sales (TRY)')
ax.set_xlabel('Month')
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(f'{os_imgs}/monthly_trend.png')
plt.close()

# 5. Quarterly revenue
quarterly = df.groupby('quarter')['total_sale'].sum()
print("\n--- Quarterly sales ---\n", quarterly)

fig, ax = plt.subplots(figsize=(11,5))
quarterly.plot(kind='bar', color='#8172B2', ax=ax)
ax.set_title('Quarterly Sales')
ax.set_ylabel('Total Sales (TRY)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig(f'{os_imgs}/quarterly_sales.png')
plt.close()

# 6. Payment method distribution by sales
pay_sales = df.groupby('payment_method')['total_sale'].sum().sort_values(ascending=False)
print("\n--- Sales by payment method ---\n", pay_sales)

fig, ax = plt.subplots(figsize=(7,5))
pay_sales.plot(kind='bar', color='#C44E52', ax=ax)
ax.set_title('Total Sales by Payment Method')
ax.set_ylabel('Total Sales (TRY)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(f'{os_imgs}/sales_by_payment.png')
plt.close()

# 7. Age group analysis
age_bins = [18,25,35,45,55,70]
age_labels = ['18-24','25-34','35-44','45-54','55-69']
df['age_group'] = pd.cut(df['age'], bins=age_bins, labels=age_labels, right=False, include_lowest=True)
age_group_sales = df.groupby('age_group')['total_sale'].sum()
print("\n--- Sales by age group ---\n", age_group_sales)

fig, ax = plt.subplots(figsize=(8,5))
age_group_sales.plot(kind='bar', color='#937860', ax=ax)
ax.set_title('Total Sales by Age Group')
ax.set_ylabel('Total Sales (TRY)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(f'{os_imgs}/sales_by_age_group.png')
plt.close()

# 8. Top selling category per mall (pivot)
mall_cat = df.groupby(['shopping_mall','category'])['total_sale'].sum().reset_index()
top_cat_per_mall = mall_cat.loc[mall_cat.groupby('shopping_mall')['total_sale'].idxmax()].sort_values('total_sale', ascending=False)
print("\n--- Top-selling category per mall ---\n", top_cat_per_mall.to_string(index=False))

# Save cleaned data
df.to_csv('/home/claude/work/cleaned_customer_shopping_data.csv', index=False)
print("\nSaved cleaned dataset.")
